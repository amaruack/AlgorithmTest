create definer = rino@`%` view cur_info as
select count(0) AS `count(*)`, sum(`rino_gateway`.`cin`.`cs`) AS `sum(cs)`
from `rino_gateway`.`cin`
where (`rino_gateway`.`cin`.`pi` = '/Mobius/ae-edu1/cnt-co2');

