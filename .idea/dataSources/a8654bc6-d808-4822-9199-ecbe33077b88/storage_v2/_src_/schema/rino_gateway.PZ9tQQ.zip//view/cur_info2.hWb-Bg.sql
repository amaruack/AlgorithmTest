create definer = rino@`%` view cur_info2 as
select count(0) AS `count(*)`, sum(`rino_gateway`.`cin`.`cs`) AS `sum(cs)`
from `rino_gateway`.`cin`
where (`rino_gateway`.`cin`.`pi` = '/Mobius/UTM_01/GCS_Data');

