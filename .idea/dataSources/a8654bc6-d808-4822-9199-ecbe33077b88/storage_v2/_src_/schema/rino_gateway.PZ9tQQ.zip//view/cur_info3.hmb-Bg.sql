create definer = rino@`%` view cur_info3 as
select count(0) AS `count(*)`
from `rino_gateway`.`lookup`;

